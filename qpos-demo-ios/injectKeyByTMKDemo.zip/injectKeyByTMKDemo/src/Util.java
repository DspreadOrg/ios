import java.io.UnsupportedEncodingException;
import java.util.Hashtable;



public class Util {
	  static final String HEXES = "0123456789ABCDEF";
	  public static String byteArray2Hex( byte [] raw ) {
	    if ( raw == null ) {
	      return null;
	    }
	    final StringBuilder hex = new StringBuilder( 2 * raw.length );
	    for ( final byte b : raw ) {
	      hex.append(HEXES.charAt((b & 0xF0) >> 4))
	         .append(HEXES.charAt((b & 0x0F)));
	    }
	    return hex.toString();
	  }
	  /**
		 * convert hex sting to hex byte array 44 --> byte 0x44
		 * 
		 * @param hexString
		 * @return
		 */
		public static byte[] HexStringToByteArray(String hexString) {//
			if (hexString == null || hexString.equals("")) {
				return new byte[]{};
			}
			if (hexString.length() == 1 || hexString.length() % 2 != 0) {
				hexString = "0" + hexString;
			}
			hexString = hexString.toUpperCase();
			int length = hexString.length() / 2;
			char[] hexChars = hexString.toCharArray();
			byte[] d = new byte[length];
			for (int i = 0; i < length; i++) {
				int pos = i * 2;
				d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
			}
			return d;
		}

		private static byte charToByte(char c) {
			return (byte) "0123456789ABCDEF".indexOf(c);
		}

		/**
		 * chinese character to hex byte array
		 * 
		 * @param str
		 * @return
		 */
		public static byte[] CNToHex(String str) {
			// String string = "";
			// for (int i = 0; i < str.length(); i++) {
			// String s = String.valueOf(str.charAt(i));
			// byte[] bytes = null;
			// try {
			// bytes = s.getBytes("gbk");
			// } catch (UnsupportedEncodingException e) {
			// e.printStackTrace();
			// }
			// for (int j = 0; j < bytes.length; j++) {
			// string += Integer.toHexString(bytes[j] & 0xff);
			// }
			// }
			byte[] b = null;
			try {
				b = str.getBytes("GBK");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			return b;
		}

		/**
		 * byte array to hex string 
		 * 
		 * @param b
		 * @return
		 */
		public static String getHexString(byte[] b) {
			StringBuffer result = new StringBuffer("");
			for (int i = 0; i < b.length; i++) {
				result.append("0x" + Integer.toString((b[i] & 0xff) + 0x100, 16).substring(1) + ",");
			}
			return result.substring(0, result.length() - 1);
		}

		/**
		 * int to byte array
		 * 
		 * @param i
		 * @return
		 */
		public static byte[] IntToHex(int i) {
			String string = null;
			if (i >= 0 && i < 10) {
				string = "0" + i;
			} else {
				string = Integer.toHexString(i);
			}
			return HexStringToByteArray(string);
		}
		public static byte[] IntToHex2(int i) {
			String string = null;
			if (i >= 0 && i < 10) {
				string = "0" + i;
			} else {
				string = Integer.toHexString(i);
			}
			if(string.length() == 2){
				string = "00" + string;
			}else if (string.length() == 1) {
				string = "000" + string;
			}
			return HexStringToByteArray(string);
		}
		public static byte[] IntToHex4(int i) {
			String string = null;
			string = Integer.toHexString(i);
			switch(string.length()){
			case 7:
				string = "0" + string;
				break;
			case 6:
				string = "00" + string;
				break;
			case 5:
				string = "000" + string;
				break;
			case 4:
				string = "0000" + string;
				break;
			case 3:
				string = "00000" + string;
				break;
			case 2:
				string = "000000" + string;
				break;
			case 1:
				string = "0000000" + string;
				break;
			}
			return HexStringToByteArray(string);
		}
		
		public static byte[] IntToHex4Big(int i) {
			String string = null;
			string = Integer.toHexString(i);
			switch(string.length()){
			case 7:
				string = "0"+string;
				break;
			case 6:
				string = string + "00";
				break;
			case 5:
				string = "0"+string + "00";
				break;
			case 4:
				string = string + "0000";
				break;
			case 3:
				string = "0"+string + "0000";
				break;
			case 2:
				string = string + "000000";
				break;
			case 1:
				string = "0" + string + "000000";
				break;
			}
			return HexStringToByteArray(string);
		}
		
		
		public static byte[] IntToHex4BigLow(int i) {
			String string = null;
			string = Integer.toHexString(i);
			System.out.println("IntToHex4BigLow: "+string);
			switch(string.length()){
			case 7:
				string = "0"+string;
				string = string.substring(6,8)+ string.substring(4,6)+string.substring(2,4)+string.substring(0, 2);
				break;
			case 6:
				string = string.substring(4,6)+string.substring(2,4)+string.substring(0, 2);
				string = string + "00";
				break;
			case 5:
				string = "0"+string ;
				string = string.substring(4,6)+string.substring(2,4)+string.substring(0, 2);
				string = string + "00";
				break;
			case 4:
				string = string.substring(2,4)+string.substring(0, 2);
				string = string + "0000";
				break;
			case 3:
				string = "0"+string ;
				string = string.substring(2,4)+string.substring(0, 2);
				string = string+ "0000";
				break;
			case 2:
				string = string + "000000";
				break;
			case 1:
				string = "0"+string + "000000";
				break;
			}
			return HexStringToByteArray(string);
		}

		/**
		 * print byte array in hex string format.
		 * @param b
		 */
		public static void printHexString(byte[] b) {
			for (int i = 0; i < b.length; i++) {
				String hex = Integer.toHexString(b[i] & 0xFF);
				if (hex.length() == 1) {
					hex = '0' + hex;
				}
				System.out.print(hex.toUpperCase());
			}

		}

		/**
		 *convert hex byte array to int
		 * 
		 * @param b
		 * @return
		 */
		public static int byteArrayToInt(byte[] b) {
			int result = 0;
			for (int i = 0; i < b.length; i++) {
				result <<= 8;
				result |= (b[i] & 0xff); //
			}
			return result;
		}

		/**
		 * XOR the input byte array
		 * 
		 * @param b
		 * @param startPos
		 * @param Len
		 * @return
		 */
		public static byte XorByteStream(byte[] b, int startPos, int Len) {
			byte bRet = 0x00;
			for (int i = 0; i < Len; i++) {
				bRet ^= b[startPos + i];
			}
			return bRet;
		}
	  /**
	   * Gets the subarray from <tt>array</tt> that starts at <tt>offset</tt>.
	   */
	  public static byte[] get(byte[] array, int offset) {
	    return get(array, offset, array.length - offset);
	  }

	  /**
	   * Gets the subarray of length <tt>length</tt> from <tt>array</tt>
	   * that starts at <tt>offset</tt>.
	   */
	  public static byte[] get(byte[] array, int offset, int length) {
	    byte[] result = new byte[length];
	    System.arraycopy(array, offset, result, 0, length);
	    return result;
	  }	 
	  
	
	public static String lineNumber() {
	        StackTraceElement ste = Thread.currentThread().getStackTrace()[3];
	        String where = ste.getClassName() + " " + ste.getMethodName() + " " + ste.getLineNumber() + " ";
	        return where;
	}
	
	
	/**
	 * convert milliseconds to hours ,minutes and seconds
	 * 
	 * @param l
	 * @return
	 */
	public static String formatLongToTimeStr(Long l) {
		String str = "";
		long hour = 0;
		long minute = 0;
		float second = 0;
		second = (float) l / (float) 1000;
		if (second > 60) {
			minute = (long) (second / 60);
			second = second % 60;
			if (minute > 60) {
				hour = minute / 60;
				minute = minute % 60;
				str = hour + "hour" + minute + "minute" + second + "second";
			} else {
				str = minute + "minute" + second + "second";
			}
		} else {
			str = second + "second";
		}
		return str;

	}
	//	cd /sdcard
	//	insmod cdc_acm.ko
	//	chmod 0777 /dev/ttyACM&
	
	public static byte[] bcd2asc(byte[]src){
		byte[] results = new byte[src.length * 2];
		for(int i=0;i<src.length;i++){
		    //high Nibble convert
		    if(((src[i] & 0xF0) >> 4) <= 9){
		    	results[2*i] = (byte)(((src[i] & 0xF0) >> 4) + 0x30);
	        }else{
	        	results[2*i]  = (byte)(((src[i] & 0xF0) >> 4) + 0x37);   //upper case A~F
	        }    
	        //low Nibble convert
	        if((src[i] & 0x0F) <= 9){
	        	results[2*i + 1] = (byte)((src[i] & 0x0F) + 0x30);
	        }else{
	        	results[2*i + 1] = (byte)((src[i] & 0x0F) + 0x37);   	//upper case A~F
	        }    
	    }
		return results;
	}
	
	
	public static byte[] ecb(byte[] in) {
		
		byte[] a1 = new byte[8];
		
		for(int i = 0;i < (in.length / 8);i++){
			byte[] temp = new byte[8];
			System.arraycopy(in, i*8, temp, 0, temp.length);
			a1 = xor8(a1,temp);
		}
		if((in.length % 8 ) != 0){
			byte[] temp = new byte[8];
			System.arraycopy(in, (in.length/8)*8, temp, 0, in.length - (in.length/8)*8);
			a1 = xor8(a1,temp);
		}
		return bcd2asc(a1);
	}
	
	public static byte[] xor8(byte[] src1, byte[] src2){
	    byte[] results = new byte[8];
	    for (int i = 0; i < results.length; i++){
	    	results[i] = (byte)(src1[i] ^ src2[i]);
	    }
	    return results;
	}
}
