import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.RSAPublicKeySpec;

public class Envelope {
	
	public byte[] readMessageFile(String fileName){
		ByteArrayOutputStream baos = new ByteArrayOutputStream(); 
		FileInputStream stream = null;
		byte[] results = new byte[0];
		try {  
	        stream = new FileInputStream(fileName);  
	        int c = 0;  
	        while((c = stream.read()) != -1){  
	        	baos.write(c);
	        } 
	        results = baos.toByteArray();
	    } catch (Exception e)  {  
	        e.printStackTrace();  
	    } finally{
	    	if(stream != null){
	    		try {
					stream.close();
				} catch (IOException e) {
				}
	    	}
	    	try {
				baos.close();
			} catch (IOException e) {
			}
	    }
		return results;
	}	
	
	public byte[] packageMessage(byte[] message){
		byte[] results = new byte[message.length + 2 * 4];
		for (int i = 0;i<results.length;i++) {
			results[i] = 0;
		}
		byte[] lenBytes = Utils.int2Byte(message.length);
		System.arraycopy(lenBytes, 0, results, 0, lenBytes.length);
		System.arraycopy(message, 0, results, 2*4, message.length);
		return results;
	}	
	//return new byte[]{0X00,0X01,0X02, 0X06, 0X01, 0X02,0X01,0X09,0X01,0X09,0X08,0X09,0X01,0X09,0X08,0X08};
	public byte[] getTdesKey(){
		return new byte[]{0X00,0X01,0X02, 0X03, 0X04, 0X05,0X06,0X07,0X08,0X09,0X0A,0X0B,0X0C,0X0D,0X0E,0X0F};
	}
	
	/*public String bytes2hex(byte[] bytes){
		StringBuffer sb = new StringBuffer();
		for (byte b : bytes) {
			int i = b & 0xFF;
			if(i<0x0F){
				sb.append(0);
			}
			sb.append(Integer.toHexString(i));
		}
		return (sb.toString().toUpperCase());
	}*/
	
	public  String bytes2hex (byte[] src){  
	    StringBuilder stringBuilder = new StringBuilder("");  
	    if (src == null || src.length <= 0) {  
	        return null;  
	    }  
	    for (int i = 0; i < src.length; i++) {  
	        int v = src[i] & 0xFF;  
	        String hv = Integer.toHexString(v);  
	        if (hv.length() < 2) {  
	            stringBuilder.append(0);  
	        }  
	        stringBuilder.append(hv);  
	    }  
	    return (stringBuilder.toString().toUpperCase());  
	}  
	
	
	
	public byte[] evelope(byte[] message, RSA senderRsa, RSA receiverRsa) throws Exception{
		byte[] encrypedTdesKey = receiverRsa.encrypt(this.getTdesKey());
		byte[] encrypedMessage = encrypt(message,senderRsa);
		byte[] toSha1Message = new byte[encrypedTdesKey.length + encrypedMessage.length];
		
		System.arraycopy(encrypedTdesKey, 0, toSha1Message, 0, encrypedTdesKey.length);
		System.arraycopy(encrypedMessage, 0, toSha1Message, encrypedTdesKey.length, encrypedMessage.length);
		byte[] signedMessage = senderRsa.sign(toSha1Message);
		byte[] results = new byte[4 + encrypedTdesKey.length + encrypedMessage.length + signedMessage.length];
		int len = encrypedTdesKey.length + encrypedMessage.length + signedMessage.length;
		byte[] lenBytes = Utils.int2Byte(len);
		
		System.out.println(signedMessage.length);
		System.out.println("signed message :"+bytes2hex(signedMessage));
		System.out.println("encrypedTdesKey:"+"length--"+encrypedTdesKey.length+"--"+bytes2hex(encrypedTdesKey)+"\n"+"encrypedMessage:"+"length--"+encrypedMessage.length+"--"+bytes2hex(encrypedMessage)+"\n"+"signedMessage:"+"length--"+signedMessage.length+"--"+bytes2hex(signedMessage));
		
		System.out.println(bytes2hex(lenBytes));
		System.arraycopy(lenBytes, 0, results, 0, lenBytes.length);
		System.arraycopy(encrypedTdesKey, 0, results, lenBytes.length, encrypedTdesKey.length);
		System.arraycopy(encrypedMessage, 0, results, lenBytes.length + encrypedTdesKey.length, encrypedMessage.length);
		System.arraycopy(signedMessage, 0, results, lenBytes.length + encrypedTdesKey.length + encrypedMessage.length, signedMessage.length);
		return results ;
	}
	
	
	public byte[] encrypt(byte[] message,RSA senderRsa) throws Exception{
		byte[] packagedMessage = this.packageMessage(message);
		int blockSize = packagedMessage.length / 8;
		if((packagedMessage.length % 8) !=0){
			blockSize += 1;
		}
		byte[] padedPackagedMessage = new byte[blockSize * 8];
		for (int i = 0; i < padedPackagedMessage.length; i++) {
			padedPackagedMessage[i] = (byte)0xFF;
		}	

		System.arraycopy(packagedMessage, 0, padedPackagedMessage, 0, packagedMessage.length);
		//System.out.println("packagedMessage to des3:"+bytes2hex(padedPackagedMessage));
		
		int i=0;
		byte [] encryptedMess=new byte[blockSize * 8];
		for(i=0;i<blockSize;i++)
		{
			byte[] temp= new byte[8];
			byte[] temp2=new byte[8];
			System.arraycopy(padedPackagedMessage, i*8, temp, 0, 8);
			temp2=TDES.tdesCBCEncypt(this.getTdesKey(), temp) ;
			System.arraycopy(temp2, 0, encryptedMess, i*8, 8);
		}
		return encryptedMess ;
	}
	
	
	public byte[] sha1(byte[] message){
		byte[] results = new byte[0];
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-1");
			md.update(message);
			results = md.digest();
			System.out.println("PlainText message:"+bytesToHexString(message));
			System.out.println("sha-1:"+bytesToHexString(results));
			
		} catch (NoSuchAlgorithmException e) {
		}
		return results ;
	}
	
	public byte[] sha1(String message){
		return sha1(message.getBytes());
	}
	
	 /**
     * Convert byte[] to hex string.这里我们可以将byte转换成int，然后利用Integer.toHexString(int)来转换成16进制字符串�??
     * @param src byte[] data
     * @return hex string
     */   
    public static String bytesToHexString(byte[] src){
        StringBuilder stringBuilder = new StringBuilder("");
        if (src == null || src.length <= 0) {
            return null;
        }
        for (int i = 0; i < src.length; i++) {
            int v = src[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);
        }
        return stringBuilder.toString();
    }
    /**
     * Convert hex string to byte[]
     * @param hexString the hex string
     * @return byte[]
     */
    public static byte[] hexStringToBytes(String hexString) {
        if (hexString == null || hexString.equals("")) {
            return null;
        }
        hexString = hexString.toUpperCase();
        int length = hexString.length() / 2;
        char[] hexChars = hexString.toCharArray();
        byte[] d = new byte[length];
        for (int i = 0; i < length; i++) {
            int pos = i * 2;
            d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
        }
        return d;
    }
    /**
     * Convert char to byte
     * @param c char
     * @return byte
     */
     private static byte charToByte(char c) {
        return (byte) "0123456789ABCDEF".indexOf(c);
    }
	
	public static void main(String[] args) {
		try {
			Envelope envelope = new Envelope();
			
			String group=DukptKeys.dukptGroup;
			
            String trackipekString=DukptKeys.trackipek;
            String emvipekString=DukptKeys.emvipek;
            String pinipekString=DukptKeys.pinipek;
            
            byte[] trackipek=hexStringToBytes(trackipekString);
            byte[] emvipek=hexStringToBytes(emvipekString);
            byte[] pinipek=hexStringToBytes(pinipekString);
            
			String trackksn = DukptKeys.trackksn;
			String emvksn = DukptKeys.emvksn;
			String pinksn = DukptKeys.pinksn;
	
			
			String tmkString=DukptKeys.tmk;
			byte[] tmk=hexStringToBytes(tmkString);
//            byte[] tmk = new byte[]{0x5F,(byte)0x8B,0x2B,(byte)0x88,0x18,(byte)0x96,0x6C,0x5C,(byte)0xD4,(byte)0xCC,0x39,0x3A,(byte)0xF9,(byte)0xFC,0x77,0x22};
            
            
            String trackipek1 = envelope.bytes2hex(TDES.tdesECBDecrypt(tmk, trackipek));
            String emvipek1 = envelope.bytes2hex(TDES.tdesECBDecrypt(tmk, emvipek));
            String pinipek1 = envelope.bytes2hex(TDES.tdesECBDecrypt(tmk, pinipek));
            
            String ipekKeyStr = trackksn+trackipek1+emvksn+emvipek1+pinksn+pinipek1+group;
            
            //System.out.println(ipekKeyStr);
            
            byte[] setIpekKeyStrData = new byte[1 + 4 + ipekKeyStr.length() / 2];
            setIpekKeyStrData[0] = 5;
            byte[] lenBytes = Utils.int2Byte(ipekKeyStr.length() / 2);
            System.arraycopy(lenBytes, 0, setIpekKeyStrData, 1, lenBytes.length);
            
            byte[] ipekBytes = hexStringToBytes(ipekKeyStr);
            System.arraycopy(ipekBytes, 0, setIpekKeyStrData, 1 + lenBytes.length, ipekBytes.length);
            
            byte[] command = new byte[]{0x01,0x02,0x00,0x00};
            byte[] message2 = new byte[4 + 4 + setIpekKeyStrData.length];
            System.arraycopy(command, 0, message2, 0, command.length);
            lenBytes = Utils.int2Byte(setIpekKeyStrData.length);
            System.arraycopy(lenBytes, 0, message2, 0 + command.length, lenBytes.length);
            System.arraycopy(setIpekKeyStrData, 0, message2, 0 + command.length + lenBytes.length, setIpekKeyStrData.length);
           
            
            /* fist convert your rsa private key into PKCS#8 format
            openssl pkcs8 -topk8 -inform PEM -outform PEM -in private_key.pem  -out private_rsa_pkcs8.pem -nocrypt
            openssl pkcs8 -topk8 -inform PEM -outform DER -in private_rsa.pem  -out private_key.der -nocrypt
            n is the export data from QPOS
            */
			RSA senderRsa = new RSA();
			RSA receiverRsa = new RSA();
			
			/*config the envelop format 1024 or 2048*/
			byte RSAflag = (byte )0x00;
			senderRsa.loadPrivateKey(new FileInputStream("keys/rsa_private_pkcs8_1024.pem"));
			
			String n = DukptKeys.RSA_public_key;
			String e = "010001";
			receiverRsa.loadPublicKey(n, e);

			byte[] de = envelope.evelope(message2, senderRsa, receiverRsa);
			int blockSize = de.length / 256;
			if((de.length % 256) != 0){
				blockSize += 1;
			}
			
			byte[] pde = new byte[blockSize * 256];
			for (int i = 0; i < pde.length; i++) {
				pde[i] = (byte)0xFF;
			}
			for(int i=0;i<10000;i++)
			{
				i+=1;
			}
			System.arraycopy(de, 0, pde, 0, de.length);
			
			pde[3] = RSAflag;
			
			System.out.println("de:"+de.length+"\n"+"pde:"+pde.length);
			/*String data=envelope.bytes2hex(pde);
			StringBuffer sb=new StringBuffer();
			sb.append(data);
			if (data.length()<1024) {
				for (int i = 0; i <1024-data.length(); i++) {
					sb.append("F");
				}
			}
			String resultData=sb.toString();
			System.out.println(resultData); */
			
			System.out.println(envelope.bytes2hex(pde));
			System.out.println("length:"+envelope.bytes2hex(pde).length()); 
			/*
			FileOutputStream dst = new FileOutputStream(new File("stm8_firmware.hex.message" + ".package"));
			dst.write(pde);
			dst.close();
			
			FileWriter fw = new FileWriter(new File("stm8_firmware.hex.message" + ".package.asc"));
			fw.write(envelope.bytes2hex(pde));
			fw.close();*/
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
