/**
 * General utilities for the second chapter examples.
 */
public class Utils
{
    private static String	digits = "0123456789abcdef";
    
    /**
     * Return length many bytes of the passed in byte array as a hex string.
     * 
     * @param data the bytes to be converted.
     * @param length the number of bytes in the data block to be converted.
     * @return a hex representation of length bytes of data.
     */
    public static String toHex(byte[] data, int length)
    {
        StringBuffer	buf = new StringBuffer();
        
        for (int i = 0; i != length; i++)
        {
            int	v = data[i] & 0xff;
            
            buf.append(digits.charAt(v >> 4));
            buf.append(digits.charAt(v & 0xf));
        }
        
        return buf.toString();
    }
    
    /**
     * Return the passed in byte array as a hex string.
     * 
     * @param data the bytes to be converted.
     * @return a hex representation of data.
     */
    public static String toHex(byte[] data)
    {
        return toHex(data, data.length);
    }
    
    
    
    
    
    
    
    
    /**
     * <p>Title:鏁村瀷涓庨暱搴︿负4鐨勫瓧鑺傛暟缁勭殑浜掓崲 </p>
     * <p>Description: </p>
     * <p>Copyright: Copyright (c) 2007-5-10</p>
     * <p>Company: www.mapabc.com</p>
     * @author luoyj
     * @version 1.0
     */  
    
    /**
     * 鏁村瀷杞崲锟�?4浣嶅瓧鑺傛暟锟�?
     * @param intValue
     * @return
     */
    public static byte[] int2Byte(int intValue) {
        byte[] b = new byte[4];
        byte[] r = new byte[4];
        for (int i = 0; i < 4; i++) {
            b[i] = (byte) (intValue >> 8 * (3 - i) & 0xFF);
            //System.out.print(Integer.toBinaryString(b[i])+" ");
            //System.out.print((b[i] & 0xFF) + " ");
        }
        r[3] = b[0];
        r[2] = b[1];
        r[1] = b[2];
        r[0] = b[3];
        return r;
    }
    /**
     * 4浣嶅瓧鑺傛暟缁勮浆鎹负鏁村瀷
     * @param b
     * @return
     */
    public static int byte2Int(byte[] b) {
        int intValue = 0;
//        int tempValue = 0xFF;
        for (int i = 0; i < b.length; i++) {
            intValue += (b[i] & 0xFF) << (8 * (3 - i));
            // System.out.print(Integer.toBinaryString(intValue)+" ");
        }
        return intValue;
    }
}
