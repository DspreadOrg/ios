//
//  DUKPT_2009_CBC.h
//  DUKPT_2009_CBC_OC
//
//  Created by zengqingfu on 15/3/12.
//  Copyright (c) 2015年 zengqingfu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonDigest.h>
typedef enum : NSUInteger {
    ECBDecryptMode,
    CBCDecryptMode,
    ECBEncryptMode,
    CBCEncryptMode,
} DEorEnMode;

@interface DUKPT_2009_CBC : NSObject

+(NSData *)GenerateIPEK:(NSData *) ksn bdk: (NSData *)bdk;
+(NSData *)GetDUKPTKey:(NSData *) ksn ipek: (NSData *)ipek;
+(NSData *)GetDataKeyVariant:(NSData *) ksn ipek: (NSData *)ipek;
+(NSData *)GetPinKeyVariant:(NSData *) ksn ipek: (NSData *)ipek;
+(NSData *)GetMacKeyVariant:(NSData *) ksn ipek: (NSData *)ipek;
+(NSData *)GetDataKey:(NSData *) ksn ipek: (NSData *)ipek;
// 十六进制字符串转字节数组
+(NSData *)parseHexStr2Byte: (NSString*)hexString;
//字节数组转十六进制字符串
+(NSString*)parseByte2HexStr: (NSData *)data;
//数据补位
+(NSString *)dataFill:(NSString *)dataStr;
//密码解密
+ (NSData*)DESOperation:(CCOperation)operation algorithm:(CCAlgorithm)algorithm keySize:(size_t)keySize data:(NSData*)data key:(NSData*)key andCcoption:(CCOptions)ccoption;
//+ (NSData*)DESEnOperation:(CCOperation)operation algorithm:(CCAlgorithm)algorithm keySize:(size_t)keySize data:(NSData*)data key:(NSData*)key andencryptMode:(ECBorCBCMode)encryptMode;
@end
