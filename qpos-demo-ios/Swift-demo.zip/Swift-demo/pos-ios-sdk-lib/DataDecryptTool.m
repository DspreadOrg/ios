//
//  DataDecryptTool.m
//  Swift-demo
//
//  Created by 方正伟 on 2018/8/24.
//  Copyright © 2018年 方正伟. All rights reserved.
//

#import "DataDecryptTool.h"
#import "DUKPT_2009_CBC.h"

@implementation DataDecryptTool

//密码解密
+(NSString*)decryptionPinblock:(NSString*)ksn BDK:(NSString*)mBDK data:(NSString*)mData andCardNum:(NSString *)cardNum{
    
    NSData *byte_ksn = [DUKPT_2009_CBC parseHexStr2Byte:ksn];
    NSData *byte_bdk = [DUKPT_2009_CBC parseHexStr2Byte:mBDK];
    
    NSData *ipek = [DUKPT_2009_CBC GenerateIPEK:byte_ksn bdk:byte_bdk];
    NSString *ipekStr = [DUKPT_2009_CBC parseByte2HexStr:ipek];
    NSLog(@"ipekStr = %@", ipekStr);
    
    NSData *pinKey = [DUKPT_2009_CBC GetPinKeyVariant:byte_ksn ipek:ipek];
    NSString *pinKeyStr = [DUKPT_2009_CBC parseByte2HexStr:pinKey];
    NSLog(@"pinKeyStr = %@", pinKeyStr);
    
    NSData *desData = [DUKPT_2009_CBC DESOperation:kCCDecrypt algorithm:kCCAlgorithm3DES keySize:kCCKeySize3DES data:[DUKPT_2009_CBC parseHexStr2Byte:mData] key:[DUKPT_2009_CBC parseHexStr2Byte:pinKeyStr] andCcoption:kCCOptionPKCS7Padding | kCCOptionECBMode ];
    
    NSString *deResultStr = [DUKPT_2009_CBC parseByte2HexStr:desData];
    
    NSString *handleCardNum = [cardNum substringWithRange:NSMakeRange(cardNum.length - 13, 12)];
    handleCardNum = [NSString stringWithFormat:@"0000%@",handleCardNum];
    
    deResultStr = [self pinxCreator:handleCardNum withPinv:deResultStr];
    
    return deResultStr;
}

//卡数据的解密10218072700005E0000B
+(NSString*)decryptionTrackDataCBC:(NSString*)ksn BDK:(NSString*)mBDK data:(NSString*)mData{
    
    NSData *byte_ksn = [DUKPT_2009_CBC parseHexStr2Byte:ksn];
    NSData *byte_bdk = [DUKPT_2009_CBC parseHexStr2Byte:mBDK];
    
    NSData *ipek = [DUKPT_2009_CBC GenerateIPEK:byte_ksn bdk:byte_bdk];
    NSLog(@"ipek: %@",[DUKPT_2009_CBC parseByte2HexStr:ipek]);
    
    NSData *dataKey = [DUKPT_2009_CBC GetDataKey:byte_ksn ipek:ipek];
    NSString *dataKeyStr = [DUKPT_2009_CBC parseByte2HexStr:dataKey];
    NSLog(@"dataKey__: %@",[DUKPT_2009_CBC parseByte2HexStr:dataKey]);
    
    NSData *desData = [DUKPT_2009_CBC DESOperation:kCCDecrypt algorithm:kCCAlgorithm3DES keySize:kCCKeySize3DES data:[DUKPT_2009_CBC parseHexStr2Byte:mData] key:[DUKPT_2009_CBC parseHexStr2Byte:dataKeyStr] andCcoption:kCCOptionPKCS7Padding];
    
    NSString *resa = [DUKPT_2009_CBC parseByte2HexStr:desData];
    
    return resa;
}

+ (NSString *)pinxCreator:(NSString *)pan withPinv:(NSString *)pinv{
    
    if (pan.length != pinv.length){
        return nil;
    }
    const char *panchar = [pan UTF8String];
    const char *pinvchar = [pinv UTF8String];
    
    NSString *temp = [[NSString alloc] init];
    
    for (int i = 0; i < pan.length; i++)
    {
        int panValue = [self charToint:panchar[i]];
        int pinvValue = [self charToint:pinvchar[i]];
        
        temp = [temp stringByAppendingString:[NSString stringWithFormat:@"%X",panValue^pinvValue]];
    }
    return temp;
}

+ (int)charToint:(char)tempChar{
    
    if (tempChar >= '0' && tempChar <='9'){
        return tempChar - '0';
    }
    else if (tempChar >= 'A' && tempChar <= 'F'){
        return tempChar - 'A' + 10;
    }
    return 0;
}

@end
