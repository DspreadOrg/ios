
//
//  PosDoTradeVc.swift
//  Swift-demo
//
//  Created by 方正伟 on 2018/8/20.
//  Copyright © 2018年 方正伟. All rights reserved.
//

import UIKit
enum OperationAction {
    case InsertAction
    case SwipeAction
    case NFCAction
}

class PosDoTradeVc: UIViewController,QPOSServiceListener{
    
    lazy var pos : QPOSService? = {
       let pos = QPOSService.sharedInstance()
       return pos
    }()
    
    lazy var dotradeBtn : UIButton? = {
        let dotradeBt = UIButton()
        dotradeBt.setTitle("dotrade", for: .normal)
        dotradeBt.backgroundColor = UIColor.orange;
        dotradeBt.frame = CGRect(x: 30, y: 100, width: 90, height:40)
        dotradeBt.setTitleColor(UIColor.white, for: .normal);
        dotradeBt.setTitleColor(UIColor.black, for: .highlighted);
        dotradeBt.layer.cornerRadius = 10;
        dotradeBt.addTarget(self, action:#selector(chargeBtnPressed(_:)), for: .touchUpInside);
        return dotradeBt
    }()
    
    lazy var textViewLog : UITextView? = {
       let textViewLo = UITextView()
        textViewLo.frame = CGRect(x: 130, y: 100, width: (view.bounds.width-140), height: (view.bounds.height-100))
        textViewLo.textColor = UIColor.black
        textViewLo.font = UIFont.boldSystemFont(ofSize: 16)
        return textViewLo
    }()
    
    var btName : String?
    var terminalTime : String!
    var currencyCode : String!
    var mTransType : TransactionType!
    var batchData : String = ""
    var cardNumStr : String = ""
    var pinblockStr : String = ""
    let BDK : String = "0123456789ABCDEFFEDCBA9876543210"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white;
        
        view.addSubview(textViewLog!)
        view.addSubview(dotradeBtn!)
        pos?.setDelegate(self)
        pos?.setPosType(PosType.bluetooth_2mode)
        pos?.setQueue(nil)
        pos?.connectBT(self.btName)
        self.textViewLog?.text = "connecting bluetooth...";
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        self.pos?.disconnectBT()
        super.viewWillDisappear(true)
    }
    
    func onRequestQposConnected() {
        
        self.textViewLog?.text = "pos Connected"
    }
    
    func onRequestQposDisconnected() {
        self.textViewLog?.text = "pos Disconnected"
    }
    
    func onRequestNoQposDetected() {
        
        self.textViewLog?.text = "No pos Detected"
    }
    
    func onRequestSetAmount() {
        print("test")
        
        let alertVc = UIAlertController(title: "input money", message: nil, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "ok", style: .default) { (_) in
            
            for text in alertVc.textFields! {
                
        self.pos?.setAmount(text.text, aAmountDescribe: "Payment", currency: self.currencyCode, transactionType:self.mTransType)
            }
        }
        
        let cancelAction = UIAlertAction(title: "cancel", style: .cancel) { (_) in
            
            self.pos?.cancelSetAmount()
        }
        
        alertVc.addTextField { (textfield : UITextField) in
        
            textfield.placeholder = ""
        }
        
        alertVc.addAction(okAction)
        alertVc.addAction(cancelAction)
        present(alertVc, animated: true, completion:nil)
       
    }
    
    // Fires after amount is set for a charge, waits on swipe
    func onRequestWaitingUser() {
        
        self.textViewLog?.text = "Please insert/swipe/tap card now."
    }
    
    func onDHError(errorState:DHError!) {
        
        var stateStr : String = "";
        
        if errorState == DHError.TIMEOUT {
            stateStr = "TIMEOUT";
        }else if errorState == DHError.APDU_ERROR{
            stateStr = "APDU_ERROR";
        }else if (errorState == DHError.UNKNOWN){
            stateStr = "UNKNOWN";
        }else if (errorState == DHError.DEVICE_BUSY){
            stateStr = "DEVICE_BUSY";
        }else if (errorState == DHError.DEVICE_RESET){
            stateStr = "DEVICE_RESET";
        }else if (errorState == DHError.INPUT_INVALID){
            stateStr = "INPUT_INVALID";
        }else if (errorState == DHError.WR_DATA_ERROR){
            stateStr = "WR_DATA_ERROR";
        }else if (errorState == DHError.EMV_APP_CFG_ERROR){
            stateStr = "EMV_APP_CFG_ERROR";
        }else if (errorState == DHError.INPUT_ZERO_VALUES){
            stateStr = "INPUT_ZERO_VALUES";
        }else if (errorState == DHError.DIGITS_UNAVAILABLE){
            stateStr = "DIGITS_UNAVAILABLE";
        }else if (errorState == DHError.EMV_CAPK_CFG_ERROR){
            stateStr = "EMV_CAPK_CFG_ERROR";
        }else if (errorState == DHError.ICC_ONLINE_TIMEOUT){
            stateStr = "ICC_ONLINE_TIMEOUT";
        }else if (errorState == DHError.INPUT_OUT_OF_RANGE){
            stateStr = "INPUT_OUT_OF_RANGE";
        }else if (errorState == DHError.AMOUNT_OUT_OF_LIMIT){
            stateStr = "AMOUNT_OUT_OF_LIMIT";
        }else if (errorState == DHError.QPOS_MEMORY_OVERFLOW){
            stateStr = "QPOS_MEMORY_OVERFLOW";
        }
        self.textViewLog?.text = stateStr;
    }
    
    func onRequest(_ displayMsg: Display) {
        var msg : String = ""
        
        if displayMsg == Display.PLEASE_WAIT{
            msg = "Please wait...";
        }else if displayMsg == Display.REMOVE_CARD{
            msg = "Please remove card";
        }else if displayMsg == Display.TRY_ANOTHER_INTERFACE{
            msg = "Please try another interface";
        }else if displayMsg == Display.TRANSACTION_TERMINATED{
            msg = "Terminated";
        }else if displayMsg == Display.PIN_OK{
            msg = "Pin ok";
        }else if displayMsg == Display.INPUT_PIN_ING{
            msg = "please input pin on pos";
        }else if displayMsg == Display.MAG_TO_ICC_TRADE{
            msg = "please insert chip card on pos";
        }else if displayMsg == Display.INPUT_OFFLINE_PIN_ONLY{
            msg = "input offline pin only";
        }else if displayMsg == Display.CARD_REMOVED{
            msg = "Card Removed";
        }
        self.textViewLog?.text = msg;
    }

    
    @objc func chargeBtnPressed(_ sender: Any) {
        let dateFormatter = DateFormatter.init()
        dateFormatter.dateFormat = "yyyyMMddHHmmss"
        self.terminalTime = dateFormatter.string(from: Date())
        self.currencyCode = "0156"
        self.mTransType = TransactionType.GOODS
        self.batchData = ""
        self.textViewLog?.text = ""
        pos?.doTrade(5)
    }
    
    func onDoTradeResult(_ result: DoTradeResult, decodeData: [AnyHashable : Any]!) {
        print(("onDoTradeResult?>> result \(result)"))
        print(decodeData);
        
        if result == DoTradeResult.ICC {
            //insert card
            self.pos?.doEmvApp(EmvOption.START)
            
        }else if result == DoTradeResult.MCR{
            //swipe card
            self.decryptDataDict(dict: decodeData! as NSDictionary,operationAction: .SwipeAction)
            
        }else if result == DoTradeResult.NFC_ONLINE{
            //NFC card
            self.decryptDataDict(dict: decodeData! as NSDictionary,operationAction: .NFCAction)
        }
    }
    
    func decryptDataDict(dict : NSDictionary,operationAction:OperationAction) {
        
        if dict.count <= 1 {
            return
        }
        
        let formatID = dict.object(forKey:"formatID");
        let maskedPAN = dict.object(forKey:"maskedPAN");
        let expiryDate = dict.object(forKey:"expiryDate");
        let cardHoldName = dict.object(forKey:"cardholderName");
        let pinksn = dict.object(forKey:"pinKsn") as! String
        let trackksn = dict.object(forKey:"trackksn");
        let servicecode = dict.object(forKey:"serviceCode");
        cardNumStr = dict.object(forKey:"encTrack2") as! String
        pinblockStr = dict.object(forKey:"pinblock") as! String

        cardNumStr = DataDecryptTool.decryptionTrackDataCBC(trackksn as! String, bdk:BDK, data: cardNumStr)
        
        let strRange = cardNumStr.range(of:"D")
        
        cardNumStr = cardNumStr.substring(to: (strRange?.lowerBound)!)
        
        if pinblockStr.characters.count > 0 && pinksn.characters.count > 0 {
            
           pinblockStr = DataDecryptTool.decryptionPinblock(pinksn, bdk:BDK , data: pinblockStr, andCardNum: cardNumStr)
        }
        
        if operationAction == .SwipeAction {
            self.textViewLog?.text = "Swipe Card:\nformatID:\(formatID ?? "")\nmaskedPAN:\(maskedPAN ?? "")\nexpiryDate:\(expiryDate ?? "")\ncardHoldName:\(cardHoldName ?? "")\npinksn:\(pinksn)\ntrackksn:\(trackksn ?? "")\nservicecode:\(servicecode ?? "")\ncardNum:\(cardNumStr)\npinblock:\(pinblockStr)";
        }else{
            
            self.textViewLog?.text = "NFC Card:\nformatID:\(formatID ?? "")\nmaskedPAN:\(maskedPAN ?? "")\nexpiryDate:\(expiryDate ?? "")\ncardHoldName:\(cardHoldName ?? "")\npinksn:\(pinksn)\ntrackksn:\(trackksn ?? "")\nservicecode:\(servicecode ?? "")\ncardNum:\(cardNumStr)\npinblock:\(pinblockStr)";
        }
        
    }
    
    func onRequestTime() {
        
        self.pos?.sendTime(self.terminalTime)
    }
    
    func onRequestIsServerConnected() {
        
        self.textViewLog?.text = "Server Connected...."
    }
    
    func onRequestOnlineProcess(_ tlv: String!) {
    
        let dict = DecryptTLV.decryptTLV(toDict: tlv)
        let C0 = dict?.object(forKey: "C0")
        let C2 = dict?.object(forKey: "C2")
        
        var c2Data : String = ""
        
        if C0 != nil && C2 != nil {
            
            c2Data = DataDecryptTool.decryptionTrackDataCBC(C0 as! String, bdk:BDK, data: C2 as! String)
        }
        
        let c2DataTLV = DecryptTLV.decryptTLV(toDict: c2Data)
        
        let C4 = c2DataTLV?.object(forKey: "5A")
        
        if  C4 != nil{
            cardNumStr = C4 as! String;
        }
        
        if cardNumStr.contains("F") {
            
            let strRange = cardNumStr.range(of:"F")
            cardNumStr = cardNumStr.substring(to: (strRange?.lowerBound)!)
        }
        
        let c1 = dict?.object(forKey: "C1") as! String//pin ksn
        let c7 = dict?.object(forKey: "C7") as! String//pinblock
        
        if (c1.characters.count > 0 && c7.characters.count > 0) {
    
            pinblockStr = DataDecryptTool.decryptionPinblock(c1, bdk: BDK, data: c7, andCardNum: cardNumStr)
        }
        
        
        /*
         6210676802158320474
         encryptMode = 16;
         ksn = 00000000000002E0000C;
         pin = 2EA0C848557751CA;
         */
        self.pos?.sendOnlineProcessResult("8A023030")
        self.textViewLog?.text = "Online process requested."
        
        print(tlv)
    }
    
    func onRequestBatchData(_ tlv: String!) {
        
        self.batchData = tlv
        print(tlv)
    }
    
    func onRequest(_ transactionResult: TransactionResult) {
        
        var message3 = "";
        if transactionResult == TransactionResult.APPROVED {
            
            message3 = "approve";
        }else if transactionResult == TransactionResult.TERMINATED{
            
            message3 = "terminated";
            
        }else if transactionResult == TransactionResult.DECLINED{
    
            message3 = "decline";
        }else if transactionResult == TransactionResult.CANCEL{
        
            message3 = "cancel";
        }else if transactionResult == TransactionResult.CAPK_FAIL{
            
            message3 = "capk fail";
            
        }else if transactionResult == TransactionResult.NOT_ICC{
            
            message3 = "not icc";
            
        }else if transactionResult == TransactionResult.SELECT_APP_FAIL{
            
            message3 = "app fail";
            
        }else if transactionResult == TransactionResult.DEVICE_ERROR{
        
            message3 = "device error";
            
        }else if transactionResult == TransactionResult.CARD_NOT_SUPPORTED{
            
            message3 = "card not supported";
            
        }else if transactionResult == TransactionResult.MISSING_MANDATORY_DATA{
            
            message3 = "missing mandatory data";
            
        }else if transactionResult == TransactionResult.CARD_BLOCKED_OR_NO_EMV_APPS{
        
            message3 = "card blocked or no emv apps";
            
        }else if transactionResult == TransactionResult.INVALID_ICC_DATA{
            
            message3 = "invalid icc data";
            
        }else if transactionResult == TransactionResult.FALLBACK{
            
            message3 = "fallback";
            
        }else if transactionResult == TransactionResult.NFC_TERMINATED{
            
            message3 = "NFC terminated";
            
        }else if transactionResult == TransactionResult.TRADE_LOG_FULL{
            
            message3 = "trade log full";
        }
        
        self.textViewLog?.text = "TransactionResult:\(message3)\ncardNumber:\(cardNumStr)\npin:\(pinblockStr)\nBatch Data:\(self.batchData)"
    }
    
    
}




