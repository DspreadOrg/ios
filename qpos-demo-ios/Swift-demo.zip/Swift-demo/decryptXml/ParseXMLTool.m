//
//  ParseXMLTool.m
//  Swift-demo
//
//  Created by 方正伟 on 2018/9/14.
//  Copyright © 2018年 方正伟. All rights reserved.
//

#import "ParseXMLTool.h"

@implementation ParseXMLTool

//解析xml
+ (NSArray *)requestXMLData:(EMVXML)appOrCapk {
    
    NSString *xml_Path = [[NSBundle mainBundle] pathForResource:@"emv_profile_tlv_20180717" ofType:@"xml"];
    
    NSData *xml_data = [[NSData alloc] initWithContentsOfFile:xml_Path];;
    //  加载xml文档
    GDataXMLDocument *document = [[GDataXMLDocument alloc] initWithData:xml_data error:NULL];
    //  获取根节点
    GDataXMLElement *rootElement = document.rootElement;
    //  创建可变的数据保存模型元素
    NSMutableArray *modelArray = [NSMutableArray array];
    //  遍历根节点的子元素，完成字典转模型
    for (GDataXMLElement *videoElement in rootElement.children) {
        
        if (appOrCapk == EMVAppXMl) {
            
            if ([videoElement.name isEqualToString:@"app"]) {
                
                TagApp *video = [[TagApp alloc] init];
                
                //  遍历这个video的属性字典，给模型的属性赋值
                for (GDataXMLNode *attribute in videoElement.attributes) {
                    //  使用kvc方式给对象的数据赋值
                    
                    [video setValue:attribute.stringValue forKey:attribute.name];
                }
                //  遍历video的子节点，给模型的属性赋值
                for (GDataXMLElement *subVideoElement in videoElement.children) {
                    //  使用kvc的方式给对象的属性赋值
                    [video setValue:subVideoElement.stringValue forKey:subVideoElement.name];
                }
                
                [modelArray addObject:video];
            }
            
        }else{
            
            if ([videoElement.name isEqualToString:@"capk"]) {
                
                TagCapk *video = [[TagCapk alloc] init];
                
                //  遍历这个video的属性字典，给模型的属性赋值
                for (GDataXMLNode *attribute in videoElement.attributes) {
                    //  使用kvc方式给对象的数据赋值
                    
                    [video setValue:attribute.stringValue forKey:attribute.name];
                }
                //  遍历video的子节点，给模型的属性赋值
                for (GDataXMLElement *subVideoElement in videoElement.children) {
                    //  使用kvc的方式给对象的属性赋值
                    [video setValue:subVideoElement.stringValue forKey:subVideoElement.name];
                }
                
                [modelArray addObject:video];
            }
        }
    }
    
    return modelArray.copy;
}
@end
