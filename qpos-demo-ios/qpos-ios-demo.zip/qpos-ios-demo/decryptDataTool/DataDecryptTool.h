//
//  DataDecryptTool.h
//  Swift-demo
//
//  Created by 方正伟 on 2018/8/24.
//  Copyright © 2018年 方正伟. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataDecryptTool : NSObject
/*
 mData:pinblock
 cardNum: cardNumber
 */
//pin decrypt function
+(NSString*)decryptionPinblock:(NSString*)ksn BDK:(NSString*)mBDK data:(NSString*)mData andCardNum:(NSString *)cardNum;

//cardNumber decrypt function
+(NSString*)decryptionTrackDataCBC:(NSString*)ksn BDK:(NSString*)mBDK data:(NSString*)mData;

@end
