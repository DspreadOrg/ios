//
//  EmvAppTag.m
//  01-DOM方式解析XML
//
//  Created by 方正伟 on 2018/8/1.
//  Copyright © 2018年 KY. All rights reserved.
//

#import "EmvAppTag.h"

@implementation EmvAppTag

- (NSString *)description {
    
    return [NSString stringWithFormat:@"---%@----%@---", self.Acquirer_Identifier,self.Additional_Terminal_Capabilities];
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}
/*
 "Acquirer_Identifier" = AF01;
 "Additional_Terminal_Capabilities" = AF40;
 "Application_Identifier_AID_terminal" = AF06;
 "Application_Selection_Indicator" = DF01;
 "Application_Version_Number" = AF09;
 "Contactless_Terminal_Additional_Capabilities" = DF7A;
 "Contactless_Terminal_Capabilities" = DF79;
 "Contactless_Terminal_Execute_Cvm_Limit" = DF78;
 "Currency_Exchange_Transaction_Reference" = DF70;
 "Currency_conversion_factor" = AF73;
 "Default_DDOL" = DF14;
 "Default_Tdol" = DF76;
 "Electronic_cash_Terminal_Transaction_Limit" = AF7B;
 ICS = DF72;
 "Identity_of_each_limit_exist" = DF74;
 "Interface_Device_IFD_Serial_Number" = AF1E;
 "Maximum_Target_Percentage_to_be_used_for_Biased_Random_Selection" = DF16;
 "Merchant_Category_Code" = AF15;
 "Merchant_Identifier" = AF16;
 "Merchant_Name_and_Location" = AF4E;
 "Point_of_Service_POS_EntryMode" = AF39;
 "Script_length_Limit" = DF71;
 "TAC_Default" = DF11;
 "TAC_Denial" = DF13;
 "TAC_Online" = DF12;
 "Target_Percentage_to_be_Used_for_Random_Selection" = DF17;
 "Terminal_Capabilities" = AF33;
 "Terminal_Country_Code" = AF1A;
 "Terminal_Default_Transaction_Qualifiers" = AF66;
 "Terminal_Floor_Limit" = AF1B;
 "Terminal_Identification" = AF1C;
 "Terminal_type" = AF35;
 "Threshold_Value_BiasedRandom_Selection" = DF15;
 "Transaction_Currency_Code" = AF2A;
 "Transaction_Currency_Exponent" = AF36;
 "Transaction_Reference_Currency_Code" = AF3C;
 "Transaction_Reference_Currency_Exponent" = AF3D;
 status = DF73;
 "terminal_contactless_offline_floor_limit" = DF19;
 "terminal_contactless_transaction_limit" = DF20;
 "terminal_execute_cvm_limit" = DF21;
 "terminal_status_check" = DF75;
 }
 */
- (void)setValue:(id)value forKey:(NSString *)key{
    
    if ([key isEqualToString:@"AF01"]) {
        
        _Acquirer_Identifier = value;
        
    }else if ([key isEqualToString:@"AF40"]){
        
        _Additional_Terminal_Capabilities = value;
        
    }else if ([key isEqualToString:@"AF06"]){
        
        _Application_Identifier_AID_terminal = value;
        
    }else if ([key isEqualToString:@"DF01"]){
        
        _Application_Selection_Indicator = value;
        
    }else if ([key isEqualToString:@"AF09"]){
        
        _Application_Version_Number = value;
    }else if ([key isEqualToString:@"DF7A"]){
        
        _Contactless_Terminal_Additional_Capabilities = value;
        
    }else if ([key isEqualToString:@"DF79"]){
        
        _Contactless_Terminal_Capabilities = value;
        
    }else if ([key isEqualToString:@"DF78"]){
        
        _Contactless_Terminal_Execute_Cvm_Limit = value;
        
    }else if ([key isEqualToString:@"DF70"]){
        
        _Currency_Exchange_Transaction_Reference = value;
        
    }else if ([key isEqualToString:@"AF73"]){
        
        _Currency_conversion_factor = value;
        
    }else if ([key isEqualToString:@"DF14"]){
        
        _Default_DDOL = value;
        
    }else if ([key isEqualToString:@"DF76"]){
        
        _Default_Tdol = value;
        
    }else if ([key isEqualToString:@"AF7B"]){
        
        _Electronic_cash_Terminal_Transaction_Limit = value;
        
    }else if ([key isEqualToString:@"DF72"]){
        
        _ICS = value;
    }else if ([key isEqualToString:@"DF74"]){
        
        _Identity_of_each_limit_exist = value;
        
    }else if ([key isEqualToString:@"AF1E"]){
        
        _Interface_Device_IFD_Serial_Number = value;
        
    }else if ([key isEqualToString:@"DF16"]){
        
        _Maximum_Target_Percentage_to_be_used_for_Biased_Random_Selection = value;
        
    }else if ([key isEqualToString:@"AF15"]){
        
        _Merchant_Category_Code = value;
        
    }else if ([key isEqualToString:@"AF16"]){
        
        _Merchant_Identifier = value;
        
    }else if ([key isEqualToString:@"AF4E"]){
        
        _Merchant_Name_and_Location = value;
        
    }else if ([key isEqualToString:@"AF39"]){
        
        _Point_of_Service_POS_EntryMode = value;
        
    }else if ([key isEqualToString:@"DF71"]){
        
        _Script_length_Limit= value;
    }else if ([key isEqualToString:@"DF11"]){
        /*
         "TAC_Default" = DF11;
         "TAC_Denial" = DF13;
         "TAC_Online" = DF12;
         "Target_Percentage_to_be_Used_for_Random_Selection" = DF17;
         "Terminal_Capabilities" = AF33;
         "Terminal_Country_Code" = AF1A;
         "Terminal_Default_Transaction_Qualifiers" = AF66;
         "Terminal_Floor_Limit" = AF1B;
         "Terminal_Identification" = AF1C;
         "Terminal_type" = AF35;
         "Threshold_Value_BiasedRandom_Selection" = DF15;
         "Transaction_Currency_Code" = AF2A;
         "Transaction_Currency_Exponent" = AF36;
         "Transaction_Reference_Currency_Code" = AF3C;
         "Transaction_Reference_Currency_Exponent" = AF3D;
         status = DF73;
         "terminal_contactless_offline_floor_limit" = DF19;
         "terminal_contactless_transaction_limit" = DF20;
         "terminal_execute_cvm_limit" = DF21;
         "terminal_status_check" = DF75;
         */
        _TAC_Default = value;
    }else if ([key isEqualToString:@"DF13"]){
        
        _TAC_Denial = value;
    }else if ([key isEqualToString:@"DF12"]){
        
        _TAC_Online = value;
        
    }else if ([key isEqualToString:@"DF17"]){
        
        _Target_Percentage_to_be_Used_for_Random_Selection = value;
    }else if ([key isEqualToString:@"AF33"]){
        
        _Terminal_Capabilities = value;
        
    }else if ([key isEqualToString:@"AF1A"]){
        
        _Terminal_Country_Code = value;
    }else if ([key isEqualToString:@"AF66"]){
        
        _Terminal_Default_Transaction_Qualifiers = value;
        
    }else if ([key isEqualToString:@"AF1B"]){
        
        _Terminal_Floor_Limit = value;
    }else if ([key isEqualToString:@"AF1C"]){
        /*
         "Terminal_Country_Code" = AF1A;
         "Terminal_Default_Transaction_Qualifiers" = AF66;
         "Terminal_Floor_Limit" = AF1B;
         "Terminal_Identification" = AF1C;
         "Terminal_type" = AF35;
         "Threshold_Value_BiasedRandom_Selection" = DF15;
         "Transaction_Currency_Code" = AF2A;
         "Transaction_Currency_Exponent" = AF36;
         "Transaction_Reference_Currency_Code" = AF3C;
         "Transaction_Reference_Currency_Exponent" = AF3D;
         status = DF73;
         "terminal_contactless_offline_floor_limit" = DF19;
         "terminal_contactless_transaction_limit" = DF20;
         "terminal_execute_cvm_limit" = DF21;
         "terminal_status_check" = DF75;
         */
        _Terminal_Identification = value;
    }else if ([key isEqualToString:@"AF35"]){
        
        _Terminal_type = value;
    }else if ([key isEqualToString:@"DF15"]){
        
        _Threshold_Value_BiasedRandom_Selection = value;
        
    }else if ([key isEqualToString:@"AF2A"]){
        
        _Transaction_Currency_Code = value;
        
    }else if ([key isEqualToString:@"AF36"]){
        
        _Transaction_Currency_Exponent = value;
    }else if ([key isEqualToString:@"AF3C"]){
        
        _Transaction_Reference_Currency_Code = value;
    }else if ([key isEqualToString:@"AF3D"]){
        
        _Transaction_Reference_Currency_Exponent = value;
        
    }else if ([key isEqualToString:@"DF73"]){
        
        _status = value;
    }else if ([key isEqualToString:@"DF19"]){
        /*
         terminal_contactless_offline_floor_limit" = DF19;
         "terminal_contactless_transaction_limit" = DF20;
         "terminal_execute_cvm_limit" = DF21;
         "terminal_status_check" = DF75;
         */
        _terminal_contactless_offline_floor_limit = value;
    }else if ([key isEqualToString:@"DF20"]){
        
        _terminal_contactless_transaction_limit = value;
    }else if ([key isEqualToString:@"DF21"]){
        
        _terminal_execute_cvm_limit = value;
    }else if ([key isEqualToString:@"DF75"]){
        
        _terminal_status_check = value;
    }
}
@end
